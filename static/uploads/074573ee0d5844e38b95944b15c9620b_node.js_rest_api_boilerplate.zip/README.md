# Node.js REST API Boilerplate

Production-ready REST API with Express and MongoDB.

## Features
- JWT Authentication
- MongoDB Integration
- Input Validation
- Error Handling
- API Documentation
- Rate Limiting

## Setup
```
npm install
npm start
```